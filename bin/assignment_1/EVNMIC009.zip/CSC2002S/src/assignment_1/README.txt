Author: Michael Evans
Date: 5 August 2014

Name: Assignment 1

Description: This program compares a serial and two parallel implementations of a correlation algorithm for use in demonstrating the benefit of parallel programming.

Instructions:
1. Compile using the makefile. In the shell, cd to the directory and then run "make".
2. Run Assignment_1.class. Run "java Assignment_1"
3. The program will ask details on how you would like to run it (Serial or Parallel, the cutoff, how many times to run).